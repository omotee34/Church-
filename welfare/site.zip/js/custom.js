

  $(document).ready(function()
  {
  	$(".owl-carousel").owlCarousel({
  		autoplay:true
  	})


  });

